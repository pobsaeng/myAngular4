import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './ngif.component.html',
  styleUrls: ['./ngif.component.css']
})
export class NgifComponent implements OnInit {

  constructor() {

  }

  ngOnInit() {
  }

  isValid: boolean = true;
  age: number = 12;
  changeValue(valid: boolean) {
    this.isValid = valid;
  }


}

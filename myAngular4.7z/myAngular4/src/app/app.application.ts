import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.application.html',
  styleUrls: ['./app.component.css']
})
export class Application {
  title = 'Application app works 55555!';
}
